#!/usr/bin/env python3
"""
make_rev2.py: builds the 3D graph rev 2 in Ralph's SG structure.

  Layer 1  State Graph       one state node per Box, linked by transitions
  Layer 2  UX subgraphs      exactly one per state: UX entry -> surfaces -> UI elements
  Layer 3  Global subgraphs  one Db, one API and one Logic subgraph for the whole app
  Layer 4  Foundation        databases and outside services under the global subgraphs

  python3 make_rev2.py boxes.json template_rev2.html sga-graph-rev2.html
"""
import json
import os
import re
import sys
from collections import OrderedDict, Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_graph  # noqa: E402  (screen links, data sources, event kinds)

# UI component types are not in the Box documents, so they are estimated from element names.
COMPONENTS = [
    ('dropdown list box', r'drop-?down|\bselect(or)?\b|picker|combo'),
    ('menu', r'\bmenu\b|kebab|overflow'),
    ('text field', r'\bfield\b|\binput\b|search (box|bar)|text ?box|textarea|editor|composer'),
    ('tab', r'\btabs?\b'),
    ('toggle or checkbox', r'toggle|switch|checkbox|check box|radio'),
    ('button', r'button|\bbtn\b|\bcta\b'),
    ('icon', r'\bicon\b|×|\bclose\b'),
    ('table, list or row', r'\brow\b|table|\blist\b|column'),
    ('card, tile or badge', r'\bcard\b|tile|\bkpi\b|chip|pill|badge'),
    ('chart or map', r'chart|\bmap\b|gantt|globe|graph|timeline'),
    ('text or heading', r'title|label|header|heading|caption|subtitle|\btext\b|\bname\b'),
]
DB_AREAS = OrderedDict([
    ('investments', 'Investment records'), ('assets', 'Asset register and risk models'), ('plans', 'Plan and portfolio records'),
    ('frameworks', 'Value and strategy frameworks'), ('docs', 'Document store'), ('collab', 'Collaboration store'),
    ('users', 'User directory'), ('versions', 'Versioning and audit log'), ('session', 'Session state (in the browser)'),
    ('other', 'Other or unnamed data'),
])
API_PORTS = OrderedDict([
    ('cooper', ('Cooper AI port', 'fd:anthropic')), ('gis', ('GIS and map port', 'fd:arcgis')), ('voice', ('Voice input port', 'fd:elevenlabs')),
    ('notify', ('Notification port', 'fd:notify')), ('search', ('AI search port', 'fd:search')), ('files', ('Device files port', 'fd:files')),
    ('external', ('Other outside port', 'fd:other')),
])
FOUNDATION = OrderedDict([
    ('fd:postgres', ('Postgres', 'Application data. The Db subgraph resolves here.')),
    ('fd:graphstore', ('Graph store (Neo4j or Postgres)', 'Holds the synthetic graph itself. The Spider reads it through GraphReader.')),
    ('fd:arcgis', ('ArcGIS', 'Maps and features for the Explore screens.')),
    ('fd:anthropic', ('Anthropic (Claude)', 'Cooper’s answers and recommendations.')),
    ('fd:elevenlabs', ('ElevenLabs', 'Cooper’s voice.')),
    ('fd:notify', ('Notification service', 'Email and in-app notifications.')),
    ('fd:search', ('AI search service', 'Search and suggestions. Provider: Needs Confirmation.')),
    ('fd:files', ('Device files', 'Uploads and downloads from the user’s computer.')),
    ('fd:other', ('Other outside services', 'Outside actions the Boxes do not name.')),
    ('fd:calc', ('Calculation service (planned)', 'Not built yet: only box-04 computes, in the browser.')),
])


def norm(text):
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]+', ' ', text.lower())).strip()


def component(label):
    low = label.lower()
    for name, pattern in COMPONENTS:
        if re.search(pattern, low):
            return name
    return 'other'


def main(boxes_path, template_path, out_path):
    tmp = os.path.join(os.path.dirname(os.path.abspath(out_path)), 'page-data.json')
    build_graph.main(boxes_path, tmp)
    D = json.load(open(tmp, encoding='utf-8'))
    found_kind = {f['id']: f['kind'] for f in D['foundations']}
    nodes, links = [], []
    ids = set()

    def add(n):
        if n['id'] not in ids:
            ids.add(n['id'])
            nodes.append(n)

    def link(s, t, kind):
        links.append({'source': s, 'target': t, 'kind': kind})

    # global entries
    add({'id': 'db:entry', 'kind': 'entry', 'part': 'db', 'name': 'Db subgraph (entry node)'})
    add({'id': 'api:entry', 'kind': 'entry', 'part': 'api', 'name': 'API subgraph (entry node)'})
    add({'id': 'logic:entry', 'kind': 'entry', 'part': 'logic', 'name': 'Logic subgraph (entry node)'})
    db_items, api_calls = {}, {}

    for b in D['boxes']:
        sid = b['id']
        add({'id': sid, 'kind': 'state', 'name': b['name'], 'module': b['module'].lower(), 'number': b['number'],
             'desc': b['description'][:420], 'figma': b['figma']})
        ux = f'ux:{sid}'
        add({'id': ux, 'kind': 'ux', 'part': 'ux', 'state': sid, 'name': f'UX subgraph of {b["name"]}'})
        link(sid, ux, 'has_ux')
        for si, s in enumerate(b['surfaces']):
            sf = f'sf:{sid}:{si}'
            add({'id': sf, 'kind': 'surface', 'part': 'ux', 'state': sid, 'name': s['name']})
            link(ux, sf, 'has_surface')
            for ei, e in enumerate(s['els']):
                el = f'el:{sid}:{si}:{ei}'
                add({'id': el, 'kind': 'element', 'part': 'ux', 'state': sid, 'name': e['l'], 'does': e['d'], 'itype': e['t'],
                     'comp': component(e['l']), 'ev': e.get('ev'), 'fig': e.get('fig'), 'to': e.get('to', [])})
                link(sf, el, 'has_element')
                if e['t'] == 'External':
                    port = e.get('f') or 'external'
                    key = (port, norm(e['l']))
                    if key not in api_calls:
                        api_calls[key] = {'id': f'call:{len(api_calls)}', 'kind': 'item', 'part': 'api', 'name': e['l'], 'port': port,
                                          'detail': e['d'], 'users': []}
                    api_calls[key]['users'].append(sid)
                    link(el, api_calls[key]['id'], 'uses_api')
        for d in b['datasets']:
            f = d['f']
            if found_kind.get(f) == 'service' or f in API_PORTS:
                port = f if f in API_PORTS else 'external'
                key = (port, norm(d['name']))
                if key not in api_calls:
                    api_calls[key] = {'id': f'call:{len(api_calls)}', 'kind': 'item', 'part': 'api', 'name': d['name'], 'port': port,
                                      'detail': d['source'], 'users': []}
                api_calls[key]['users'].append(sid)
                link(ux, api_calls[key]['id'], 'uses_api')
            else:
                area = f if f in DB_AREAS else 'other'
                key = (area, norm(d['name']))
                if key not in db_items:
                    db_items[key] = {'id': f'data:{len(db_items)}', 'kind': 'item', 'part': 'db', 'name': d['name'], 'area': area,
                                     'detail': d['source'], 'columns': d['columns'][:240], 'users': []}
                db_items[key]['users'].append(sid)
                link(ux, db_items[key]['id'], 'uses_data')
        groups = OrderedDict()
        for r in b['rules']:
            groups.setdefault(r['g'], []).append(r['r'][:220])
        for gi, (g, rules) in enumerate(groups.items()):
            lg = f'logic:{sid}:{gi}'
            add({'id': lg, 'kind': 'item', 'part': 'logic', 'name': g if g != 'General rules' else f'Rules of {b["name"]}',
                 'state': sid, 'count': len(rules), 'rules': rules, 'users': [sid]})
            link('logic:entry', lg, 'contains')
            link(ux, lg, 'uses_logic')

    # Db areas and items
    used_areas = sorted({i['area'] for i in db_items.values()}, key=list(DB_AREAS).index)
    for a in used_areas:
        add({'id': f'area:{a}', 'kind': 'group', 'part': 'db', 'name': DB_AREAS[a]})
        link('db:entry', f'area:{a}', 'contains')
    for it in db_items.values():
        it['users'] = sorted(set(it['users']))
        add(it)
        link(f'area:{it["area"]}', it['id'], 'contains')
    # API ports and calls
    used_ports = sorted({c['port'] for c in api_calls.values()}, key=list(API_PORTS).index)
    for p in used_ports:
        add({'id': f'port:{p}', 'kind': 'group', 'part': 'api', 'name': API_PORTS[p][0], 'port': p})
        link('api:entry', f'port:{p}', 'contains')
    for c in api_calls.values():
        c['users'] = sorted(set(c['users']))
        add(c)
        link(f'port:{c["port"]}', c['id'], 'contains')
    # Foundation
    needed = {'fd:postgres', 'fd:graphstore', 'fd:calc'} | {API_PORTS[p][1] for p in used_ports}
    for fid, (name, desc) in FOUNDATION.items():
        if fid in needed:
            add({'id': fid, 'kind': 'foundation', 'part': 'found', 'name': name, 'detail': desc})
    link('db:entry', 'fd:postgres', 'resolves_to')
    for p in used_ports:
        link(f'port:{p}', API_PORTS[p][1], 'resolves_to')
    link('logic:entry', 'fd:calc', 'planned')
    # State Graph transitions (between Boxes only)
    box_ids = {b['id'] for b in D['boxes']}
    for t in D['transitions']:
        if t['from'] in box_ids and t['to'] in box_ids:
            links.append({'source': t['from'], 'target': t['to'], 'kind': 'transition', 'basis': t['basis'], 'via': t['via'][:2]})

    count = Counter(n['kind'] + ':' + n.get('part', '') for n in nodes)
    comps = Counter(n['comp'] for n in nodes if n['kind'] == 'element')
    meta = {
        'states': sum(1 for n in nodes if n['kind'] == 'state'),
        'surfaces': count['surface:ux'], 'elements': count['element:ux'],
        'dbItems': len(db_items), 'dbAreas': len(used_areas), 'apiCalls': len(api_calls), 'apiPorts': len(used_ports),
        'logicGroups': count['item:logic'], 'rules': sum(len(b['rules']) for b in D['boxes']),
        'foundation': count['foundation:found'], 'transitions': sum(1 for l in links if l['kind'] == 'transition'),
        'components': dict(comps.most_common()),
        'modules': ['command', 'value', 'explore', 'build', 'plan'],
    }
    data = {'meta': meta, 'nodes': nodes, 'links': links}
    blob = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    page = open(template_path, encoding='utf-8').read().replace('__REV2_DATA__', blob)
    open(out_path, 'w', encoding='utf-8').write(page)
    print(json.dumps(meta, indent=1))
    print(f'{len(nodes)} nodes, {len(links)} links, page {len(page) // 1024} KB')


if __name__ == '__main__':
    main(*sys.argv[1:4])
