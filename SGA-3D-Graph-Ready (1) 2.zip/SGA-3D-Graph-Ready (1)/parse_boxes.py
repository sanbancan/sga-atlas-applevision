#!/usr/bin/env python3
"""
parse_boxes.py: turns the Box documents (Word files) into graph data for the 3D page.

How to use it:
  1. Download the "Archive" Boxes folder from Google Drive as a zip.
  2. Run:  python3 parse_boxes.py Archive.zip boxes.json
  3. The 3D page reads the data from boxes.json (the build step pastes it in).

What it reads from every Box:
  - the title and "Screen description"
  - "The Actions": every UI element, grouped by surface (Element / What it does / Type)
  - "The Rules":   rule groups and their numbered rules (business logic)
  - "The Data":    datasets, their columns and their source (data and outside services)
It needs pandoc installed (https://pandoc.org).
"""
import json
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SECTION_NAMES = {
    'screen description': 'description',
    'the actions': 'actions',
    'the rules': 'rules',
    'the data': 'data',
}

LINK = re.compile(r'\[([^\]]*)\]\([^)]*\)')
FIGMA = re.compile(r'figma\.com/(?:design|file)/([A-Za-z0-9]+)/([^?\s)]*)\?node-id=([0-9]+[-:][0-9]+)')


def clean(text):
    """Plain text: no markdown bold, links, escapes or heading marks."""
    text = re.sub(r'^#+\s*', '', text.strip())
    text = re.sub(r'<[^>]+>', '', text)                      # stray HTML such as <span class="mark">
    text = LINK.sub(r'\1', text)
    text = text.replace('**', '').replace('__', '')
    text = text.replace('\\|', '|').replace('\\', '')
    return re.sub(r'\s+', ' ', text).strip()


def split_row(line):
    cells = re.split(r'(?<!\\)\|', line.strip())
    if cells and cells[0] == '':
        cells = cells[1:]
    if cells and cells[-1].strip() == '':
        cells = cells[:-1]
    return cells


def parse_table(rows):
    """rows: raw markdown table lines. Returns (headers, list of {header: raw cell})."""
    header = [clean(c).lower() for c in split_row(rows[0])]
    out = []
    for line in rows[1:]:
        if re.match(r'^\|?\s*:?-{3,}', line.strip()):
            continue
        cells = split_row(line)
        out.append({header[i]: cells[i] if i < len(cells) else '' for i in range(len(header))})
    return header, out


def col(row, *names):
    for key in row:
        if any(key.startswith(n) for n in names):
            return row[key]
    return ''


def parse_markdown(md, module, file_name):
    lines = md.split('\n')
    box = {
        'module': module, 'file': file_name, 'title': '', 'description': '',
        'surfaces': [], 'ruleGroups': [], 'datasets': [], 'notes': [], 'figma': None,
    }
    section = None
    surface = None
    group = None
    figma_counts = {}
    i = 0
    while i < len(lines):
        raw = lines[i]
        text = clean(raw)
        if not text:
            i += 1
            continue
        if raw.lstrip().startswith('|'):                       # a table
            block = []
            while i < len(lines) and lines[i].lstrip().startswith('|'):
                block.append(lines[i])
                i += 1
            header, rows = parse_table(block)
            if section == 'actions' and any(h.startswith('element') for h in header):
                if surface is None:
                    surface = {'name': 'Screen', 'elements': [], 'uses': []}
                    box['surfaces'].append(surface)
                for r in rows:
                    label = clean(col(r, 'element'))
                    if not label:
                        continue
                    mock = col(r, 'mock')
                    node = None
                    m = FIGMA.search(mock)
                    if m:
                        base = f'https://www.figma.com/design/{m.group(1)}/{m.group(2)}'
                        figma_counts[base] = figma_counts.get(base, 0) + 1
                        node = m.group(3).replace(':', '-')
                    surface['elements'].append({
                        'label': label,
                        'does': clean(col(r, 'what it does', 'what')),
                        'type': clean(col(r, 'type')),
                        'figmaNode': node,
                    })
            elif section == 'data' and any(h.startswith('dataset') for h in header):
                for r in rows:
                    name = clean(col(r, 'dataset'))
                    if name:
                        box['datasets'].append({
                            'name': name,
                            'columns': clean(col(r, 'columns')),
                            'source': clean(col(r, 'source')),
                        })
            continue

        low = text.lower().rstrip(':')
        is_heading = raw.lstrip().startswith('#') or (raw.strip().startswith('**') and raw.strip().endswith('**'))
        if not box['title']:
            box['title'] = text
        elif low in SECTION_NAMES:
            section = SECTION_NAMES[low]
            surface = None
            group = None
        elif low.startswith('for humans'):
            section = 'humans'
        elif section == 'description':
            box['description'] = (box['description'] + ' ' + text).strip()
        elif section == 'actions':
            if len(text) <= 90 and not text.endswith('.'):
                surface = {'name': text, 'elements': [], 'uses': []}
                box['surfaces'].append(surface)
            else:
                box['notes'].append(text)
                if surface is not None:
                    surface['uses'].append(text)
        elif section == 'data':
            box['notes'].append(text)                      # e.g. "As Box 04 ..., read from ..."
        elif section == 'rules':
            numbered = re.match(r'^\d+[.)]\s+', text)
            if not numbered and (is_heading or (len(text) <= 80 and not text.endswith('.'))):
                group = {'name': text, 'rules': []}
                box['ruleGroups'].append(group)
            else:
                if group is None:
                    group = {'name': 'General rules', 'rules': []}
                    box['ruleGroups'].append(group)
                group['rules'].append(re.sub(r'^\d+[.)]\s+', '', text))
        i += 1

    if figma_counts:
        box['figma'] = max(figma_counts, key=figma_counts.get)
    box['surfaces'] = [s for s in box['surfaces'] if s['elements'] or s['uses']]
    box['ruleGroups'] = [g for g in box['ruleGroups'] if g['rules']]
    return box


def box_number_and_name(title, file_stem):
    """'Box 02a — Entry points to Asset details (Explore)' -> ('02a', 'Entry points to Asset details')."""
    source = title if title.lower().startswith('box') else file_stem
    m = re.match(r'^Box\s+([0-9]+(?:\.[0-9]+)?[a-z]?)\s*[—–-]\s*(.*)$', source.strip(), re.I)
    if not m:
        return '', source
    number, name = m.group(1), m.group(2)
    name = re.sub(r'\s*\((Explore|Value|Build|Plan|Command|Results)\)\s*$', '', name, flags=re.I)
    name = re.sub(r'^Free Explore\s*[—–-]\s*', '', name, flags=re.I)
    return number, name.strip()


def main(zip_path, out_path):
    boxes = []
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            name = info.filename
            if not name.lower().endswith('.docx') or '/Box ' not in '/' + name.replace('\\', '/'):
                continue
            parts = Path(name).parts
            if '..' in parts:
                continue
            module = Path(name).parent.name.replace(' Boxes', '').strip()
            target = Path(tmp) / f'{len(boxes)}.docx'
            target.write_bytes(z.read(info))
            md = subprocess.run(['pandoc', str(target), '-t', 'gfm', '--wrap=none'],
                                capture_output=True, text=True, check=True).stdout
            stem = Path(name).stem.replace('#U2014', '—')
            box = parse_markdown(md, module, Path(name).name)
            box['number'], box['name'] = box_number_and_name(box['title'], stem)
            box['id'] = f"{module.lower()}-{box['number'] or len(boxes)}"
            boxes.append(box)
    boxes.sort(key=lambda b: (b['module'], [float(x) if x.replace('.', '').isdigit() else x
                                            for x in re.findall(r'\d+(?:\.\d+)?|[a-z]', b['number'])]))
    Path(out_path).write_text(json.dumps(boxes, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f'{len(boxes)} boxes written to {out_path}')


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('Usage: python3 parse_boxes.py Archive.zip boxes.json')
    main(sys.argv[1], sys.argv[2])
