#!/usr/bin/env python3
"""
build_graph.py: turns boxes.json (from parse_boxes.py) into the data the 3D page draws.

  python3 build_graph.py boxes.json page-data.json

What it adds on top of the parsed Boxes:
  - foundations: the 300+ "Source" phrases in The Data tables, grouped into a few shared
    foundation services (Document store, Cooper AI service, User directory, ...)
  - transitions: screen-to-screen links, found three ways (strongest first):
      box-ref     an action's text names another Box ("... specified in Box 14")
      module-nav  a Navigation action goes to a module ("Goes to Value")
      name-match  a Navigation action names another screen in the same module
                  ("Goes to the investment Details" -> Box 06 Investment Details)
  - reuses: "As Box 00 — Shared Components" notes (a screen reuses another Box's parts)
Links found by name-match are a first pass for people to review, not ground truth.
"""
import json
import re
import sys

MODULE_ORDER = ['Command', 'Value', 'Explore', 'Build', 'Plan', 'Results']
LANDING = {'command': 'command-01', 'value': 'value-01', 'explore': 'explore-01',
           'build': 'build-01', 'plan': 'plan-01', 'results': 'module:results'}

# Source phrase keywords -> shared foundation service. First match wins.
FOUNDATIONS = [
    ('cooper', 'Cooper AI service', 'service', r'cooper'),
    ('session', 'Session state (in the browser)', 'client', r'in-session|in session|client-side|local state|ui state|browser'),
    ('gis', 'GIS and map service', 'service', r'\bgis\b|map\b|tile|basemap|network model|geograph|feeder|spatial'),
    ('docs', 'Document store', 'database', r'document|file|attachment|evidence|photo'),
    ('collab', 'Collaboration store', 'database', r'collaborat|thread|repl|comment|presence|mention'),
    ('users', 'User directory', 'database', r'user|role|permission|account|avatar|team'),
    ('versions', 'Versioning and audit log', 'database', r'version|audit|history|activity'),
    ('plans', 'Plan and portfolio records', 'database', r'\bplan|scenario|cycle|portfolio'),
    ('frameworks', 'Value and strategy frameworks', 'database', r'framework|value model|goal|measure|questionnaire|formula|criteri|weight'),
    ('assets', 'Asset register and risk models', 'database', r'asset|regist|condition|degradation|risk|outage|sensor|signal|substation|hierarchy'),
    ('investments', 'Investment records', 'database', r'investment|alternative|cost|schedule|budget|approv|idea|review|stage'),
    ('notify', 'Notification service', 'service', r'notif|email|reminder'),
    ('search', 'AI search service', 'service', r'search|query|nlp'),
    ('other', 'Other or unnamed source', 'database', r'.'),
]
EXTERNAL = [
    ('cooper', r'cooper'),
    ('voice', r'voice|dictat|\bmic\b|microphone|spoken'),
    ('files', r'upload|download|file picker|attach|file\b|document|photo|open[s]? the (pdf|file)'),
    ('search', r'search|query|suggest'),
    ('gis', r'map|street|gis'),
    ('notify', r'email|notif|share|calendar|link'),
    ('external', r'.'),
]
EXTERNAL_NAMES = {'voice': ('Voice input service', 'service'), 'files': ('Device files (upload and download)', 'service'),
                  'external': ('Other outside service', 'service')}

# Extra names people use for screens, per Box id (used only by name-match, inside one module).
ALIASES = {
    'build-01': ['build library', 'idea pad', 'investment list'],
    'build-02': ['idea shape', 'shaping-stage', 'shaping stage', 'idea overview'],
    'build-03': ['owner review'],
    'build-04': ['stakeholder review', 'reviewer review'],
    'build-05': ['investment overview', 'investment’s overview'],
    'build-06': ['investment details', 'details page'],
    'build-07': ['alternative comparison', 'alternatives comparison', 'compare alternatives', 'comparison view'],
    'build-08': ['value screen', 'investment value'],
    'build-09': ['model details'],
    'build-10': ['alternative details'],
    'build-11': ['cost & schedule', 'cost and schedule', 'gantt'],
    'build-12': ['schedule table', 'table view'],
    'build-13': ['approval chain'],
    'build-14': ['create new investment', 'start-method chooser', 'new investment'],
    'explore-01': ['explore map', 'full map', 'map view', 'globe'],
    'explore-02a': ['entry points'],
    'explore-02b': ['asset details', 'single asset', 'details screen'],
    'explore-02c': ['group details', 'container details'],
    'explore-03': ['studies library', 'study library', 'study panel', 'saved study'],
    'explore-04': ['lens'],
    'explore-05': ['layer groups', 'map layer', 'layers panel'],
    'explore-06': ['trace report'],
    'explore-07': ['cooper recommendations', 'recommendation list'],
    'plan-01': ['plan home', 'plans list', 'plan list'],
    'plan-02': ['plan setup', 'setup'],
    'plan-03': ['plan compare', 'compare plans', 'scenario comparison', 'compare view'],
    'plan-04': ['plan approve', 'plan approval', 'approve the plan'],
    'value-0.1': ['cooper panel', 'cooper communication card', 'cooper chat'],
    'value-0.2': ['collaboration panel', 'collaborators panel'],
    'value-0.3': ['validation panel'],
    'value-0.4': ['comment panel', 'comments panel', 'comment thread'],
    'value-01': ['active framework', 'framework overview'],
    'value-02': ['framework map'],
    'value-03': ['capital flow'],
    'value-04': ['strategy framework library', 'library: strategy'],
    'value-05': ['value framework library', 'library: value framework'],
    'value-06': ['value models library', 'library: value models'],
    'value-07': ['chooser modal', 'chooser'],
    'value-08': ['duplicate flow'],
    'value-09': ['enterprise goals'],
    'value-10': ['strategy framework canvas', 'shape canvas: strategy'],
    'value-11': ['value framework canvas', 'shape canvas: value'],
    'value-12': ['shape value model', 'shape: value model'],
    'value-13': ['questionnaire'],
    'value-14': ['formula editor'],
    'value-15': ['review screen'],
    'value-16': ['send for approval'],
}

# The click path from the demo video, written as Boxes. Two links come from Box text that
# lives on another screen: Box 07's "7 risks surfaced" pill sits on the Explore header,
# and Box 07's "View details" opens the asset details screen (Box 02b).
DEMO_LINKS = [('explore-01', 'explore-07', '“7 risks surfaced” pill'),
              ('explore-07', 'explore-02b', '“View details” button')]

TEXT_ENTRY = re.compile(r'input|search (field|box|bar)|field|text box|query|enter |type |textarea|editor|note|“ask|ask anything', re.I)
MENU = re.compile(r'menu|dropdown|drop-down|\btab\b|tabs|filter|chip|toggle|select|kebab|segmented|sort|picker', re.I)


def event_kind(e):
    text = e['label'] + ' ' + e['does']
    if TEXT_ENTRY.search(e['label']):
        return 'text_entry'
    if MENU.search(text):
        return 'menu_choice'
    return 'button_click'


def foundation_for_source(source):
    s = source.lower()
    for fid, name, kind, pattern in FOUNDATIONS:
        if re.search(pattern, s):
            return fid
    return 'other'


def external_for(e):
    t = (e['label'] + ' ' + e['does']).lower()
    for fid, pattern in EXTERNAL:
        if re.search(pattern, t):
            return fid
    return 'external'


def main(src, out):
    boxes = json.load(open(src, encoding='utf-8'))
    by_id = {b['id']: b for b in boxes}
    by_number = {}
    for b in boxes:
        by_number.setdefault(b['number'].lstrip('0') or '0', []).append(b)

    def resolve_box_ref(number, text, from_box):
        key = number.lstrip('0') or '0'
        candidates = by_number.get(key, [])
        mod = re.search(r'Box\s+' + re.escape(number) + r'[^()]{0,80}\((Explore|Value|Build|Plan|Command)\)', text)
        if mod:
            candidates = [c for c in candidates if c['module'] == mod.group(1)]
        same = [c for c in candidates if c['module'] == from_box['module']]
        pick = same or candidates
        return pick[0]['id'] if len(pick) >= 1 and (same or len(pick) == 1) else None

    transitions = {}
    reuses = {}

    def add_transition(a, b, via, basis):
        if not b or a == b:
            return
        key = (a, b)
        t = transitions.setdefault(key, {'from': a, 'to': b, 'via': [], 'basis': basis})
        if via not in t['via']:
            t['via'].append(via)
        order = ['box-ref', 'module-nav', 'name-match', 'demo-path']
        if order.index(basis) < order.index(t['basis']):
            t['basis'] = basis

    for b in boxes:
        for s in b['surfaces']:
            for e in s['elements']:
                e['event'] = event_kind(e) if e['type'] in ('Navigation', 'Local change', 'External') else None
                e['targets'] = []
                if not e['event']:
                    continue
                text = e['does']
                for m in re.finditer(r'Box\s+(\d+(?:\.\d+)?[a-c]?)', text):
                    t = resolve_box_ref(m.group(1), text, b)
                    if t:
                        add_transition(b['id'], t, e['label'], 'box-ref')
                        e['targets'].append(t)
                if e['targets']:
                    continue
                low = (e['label'] + ' | ' + text).lower()
                if e['type'] == 'Local change':
                    # Panels that are their own Box (Study library, Lens, Layers...) are
                    # separate states too, so an action that opens one is a transition.
                    if re.search(r'\b(opens?|toggles?|switch(es)?|goes|returns?|navigates?|takes)\b', text.lower()):
                        best = None
                        for tid, names in ALIASES.items():
                            if tid == b['id'] or by_id.get(tid, {}).get('module') != b['module']:
                                continue
                            for n in names:
                                if n in low and (best is None or len(n) > best[1]):
                                    best = (tid, len(n))
                        if best:
                            add_transition(b['id'], best[0], e['label'], 'name-match')
                            e['targets'].append(best[0])
                    continue
                if e['type'] != 'Navigation':
                    continue
                if re.search(r'top-level product navigation', low):
                    for mod in ['command', 'value', 'explore', 'build', 'plan']:
                        add_transition(b['id'], LANDING[mod], e['label'], 'module-nav')
                        e['targets'].append(LANDING[mod])
                    continue
                if re.search(r'product home|app home|home screen|command center|command home', low):
                    add_transition(b['id'], LANDING['command'], e['label'], 'module-nav')
                    e['targets'].append(LANDING['command'])
                    continue
                m = re.match(r'^[“"]?(command|value|explore|build|plan|results)[”"]?$', e['label'].strip().lower())
                if m or re.search(r'goes to (value|explore|build|plan|results)\b', text.lower()):
                    mod = m.group(1) if m else re.search(r'goes to (value|explore|build|plan|results)\b', text.lower()).group(1)
                    add_transition(b['id'], LANDING[mod], e['label'], 'module-nav')
                    e['targets'].append(LANDING[mod])
                    continue
                if re.search(r'explore (full )?map|to the map view', low) and b['module'] != 'Explore':
                    add_transition(b['id'], 'explore-01', e['label'], 'module-nav')
                    e['targets'].append('explore-01')
                    continue
                best = None
                for tid, names in ALIASES.items():
                    if tid == b['id'] or by_id.get(tid, {}).get('module') != b['module']:
                        continue
                    for n in names:
                        if n in low and (best is None or len(n) > best[1]):
                            best = (tid, len(n))
                if best:
                    add_transition(b['id'], best[0], e['label'], 'name-match')
                    e['targets'].append(best[0])
        for note in b['notes'] + [u for s in b['surfaces'] for u in s['uses']]:
            for m in re.finditer(r'^\s*As Box\s+(\d+(?:\.\d+)?[a-c]?)|\bAs Box\s+(\d+(?:\.\d+)?[a-c]?)', note):
                num = m.group(1) or m.group(2)
                t = resolve_box_ref(num, note, b)
                if t and t != b['id']:
                    reuses.setdefault((b['id'], t), {'from': b['id'], 'to': t, 'note': note[:160]})

    for a, b2, via in DEMO_LINKS:
        add_transition(a, b2, via, 'demo-path')

    # Foundations used by datasets and by external actions.
    used = {}
    compact = []
    for b in boxes:
        datasets = []
        for d in b['datasets']:
            fid = foundation_for_source(d['source'])
            used[fid] = used.get(fid, 0) + 1
            datasets.append({'name': d['name'], 'source': d['source'], 'columns': d['columns'][:320], 'f': fid})
        surfaces = []
        for s in b['surfaces']:
            els = []
            for e in s['elements']:
                item = {'l': e['label'], 'd': e['does'], 't': e['type']}
                if e['figmaNode']:
                    item['fig'] = e['figmaNode']
                if e['event']:
                    item['ev'] = e['event']
                if e['targets']:
                    item['to'] = sorted(set(e['targets']))
                if e['type'] == 'External':
                    item['f'] = external_for(e)
                    used[item['f']] = used.get(item['f'], 0) + 1
                els.append(item)
            surfaces.append({'name': s['name'], 'els': els})
        rules = [{'g': g['name'], 'r': r} for g in b['ruleGroups'] for r in g['rules']]
        compact.append({
            'id': b['id'], 'module': b['module'], 'number': b['number'], 'name': b['name'],
            'description': b['description'][:600], 'figma': b['figma'], 'file': b['file'],
            'surfaces': surfaces, 'rules': rules, 'datasets': datasets,
        })

    names = {fid: (name, kind) for fid, name, kind, _ in FOUNDATIONS}
    names.update(EXTERNAL_NAMES)
    foundations = [{'id': fid, 'name': names[fid][0], 'kind': names[fid][1], 'uses': n}
                   for fid, n in sorted(used.items(), key=lambda x: -x[1])]
    modules = [{'id': m.lower(), 'name': m} for m in MODULE_ORDER]
    data = {
        'source': 'Box documents in the Archive folder (Explore, Value, Build, Plan, Command)',
        'modules': modules, 'boxes': compact, 'foundations': foundations,
        'transitions': sorted(transitions.values(), key=lambda t: (t['from'], t['to'])),
        'reuses': sorted(reuses.values(), key=lambda t: (t['from'], t['to'])),
        'demoJourney': {
            'screens': ['explore-01', 'explore-07', 'explore-02b'],
            'inside': {'box': 'explore-02b', 'elements': ['Documentation tab', 'Records sub-tab', 'Photo thumbnail']},
        },
    }
    json.dump(data, open(out, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    by_basis = {}
    for t in data['transitions']:
        by_basis[t['basis']] = by_basis.get(t['basis'], 0) + 1
    print(f"{len(compact)} screens, {len(foundations)} foundations, {len(data['transitions'])} transitions {by_basis}, {len(data['reuses'])} reuses")


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
