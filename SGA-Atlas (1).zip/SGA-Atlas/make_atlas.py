#!/usr/bin/env python3
"""
make_atlas.py: builds the SGA Atlas page from the rev 2 graph.

It copies the graph data out of sga-graph-rev2.html into template_atlas.html, so the
Atlas always shows the same states, UX subgraphs and global subgraphs as rev 2.

  python3 make_atlas.py sga-graph-rev2.html template_atlas.html sga-atlas.html

Run it again after make_rev2.py whenever the Box documents change.
"""
import json
import re
import sys


def main(rev2_path, template_path, out_path):
    html = open(rev2_path, encoding='utf-8').read()
    found = re.search(r'<script type="application/json" id="rev2-data">(.*?)</script>', html, re.S)
    if not found:
        sys.exit(f'No graph data in {rev2_path}. Use the generated sga-graph-rev2.html, not the template.')
    blob = found.group(1).strip()
    data = json.loads(blob)  # stops here if the data is broken
    page = open(template_path, encoding='utf-8').read()
    if '__SGA_DATA__' not in page:
        sys.exit(f'{template_path} has no __SGA_DATA__ placeholder.')
    page = page.replace('__SGA_DATA__', blob)
    open(out_path, 'w', encoding='utf-8').write(page)
    meta = data.get('meta', {})
    print(f"{out_path}: {meta.get('states')} states, {meta.get('elements')} UI elements, "
          f"{len(data['nodes'])} nodes, {len(data['links'])} links, {len(page) // 1024} KB")


if __name__ == '__main__':
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(*sys.argv[1:4])
